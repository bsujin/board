package Board;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

import kr.or.ddit.board.model.BoardListVo;
import kr.or.ddit.board.model.BoardVo;
import kr.or.ddit.board.repository.BoardDao;
import kr.or.ddit.board.service.BoardService;
import kr.or.ddit.board.service.BoardServiceI;
import kr.or.ddit.boardList.repository.BoardListDao;
import kr.or.ddit.boardList.service.BoardListService;
import kr.or.ddit.boardList.service.BoardListServiceI;
import kr.or.ddit.user.model.UserVo;
import kr.or.ddit.user.service.UserService;
import kr.or.ddit.user.service.UserServiceI;

public class BoardServiceTest {

	private BoardServiceI service;
	private BoardListServiceI blservice;
	
	// 로그인 테스트 
	@Test
	public void Logintest() {
		/***Given***/
		UserServiceI uService = new UserService();
		String userid = "con";

		/***When***/
		UserVo user = uService.selectMember(userid);
		
		/***Then***/
		assertNotNull(user);
		assertEquals("콘", user.getUsernm());

	}
	
	// 게시판 목록 조회 
	@Test
	public void test() {
		/*** Given ***/
		 service = new BoardService();
		 String userid = "con";
		/*** When ***/
		List<BoardVo> board = service.selectBoard(userid);

		/*** Then ***/
		assertEquals(3, board.size());
	}
	
	// 게시판 등록
//			@Test
//			public void addBoardtest() {
//				/*** Given ***/
//				service = new BoardService();
//				String userid = "con";
//				String board = "boardnm";
//				int a= 1;
//				BoardVo vo = new BoardVo();
//				vo.setUser_id(userid);
//				vo.setBoard_nm(board);
//				vo.setActivation(a);
//				/*** When ***/
//				int cnt = service.addBoard(vo);
//				/*** Then ***/
//				assertEquals(1, cnt);
//				assertEquals("boardnm", vo.getBoard_nm());
//			}
	@Test
	public void modifyUserTest() {
		/*** Given ***/
		service = new BoardService();
		BoardVo vo  = new BoardVo();
		vo.setActivation(1);
		vo.setBoard_no(4);
		vo.setUser_id("con");
//		
		/*** When ***/
		int updateCnt = service.modifyBoard(vo);
		
		/*** Then ***/
		assertEquals(1, updateCnt);
		
	}
	
	//////////////boardList
	// 게시판 상세조회 
	@Test
	public void detailBoardtest() {
		/*** Given ***/
		blservice = new BoardListService();
		
		BoardListVo vo = new BoardListVo();
		vo.setBoard_no(1);
		vo.setPost_no(1);
		/*** When ***/
		vo = blservice.selectPost(vo);
		/*** Then ***/
		assertEquals("1번글", vo.getTitle());
	}
	
}
