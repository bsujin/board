package BoardList;

import static org.junit.Assert.*;

import org.junit.Test;

import kr.or.ddit.board.model.BoardListVo;
import kr.or.ddit.boardList.repository.BoardListDao;
import kr.or.ddit.boardList.service.BoardListService;
import kr.or.ddit.boardList.service.BoardListServiceI;
import kr.or.ddit.file.model.FileVo;
import kr.or.ddit.file.repository.FileDao;
import kr.or.ddit.file.repository.FileDaoI;
import kr.or.ddit.file.service.FileService;
import kr.or.ddit.file.service.FileServiceI;

public class B_ListServiceTest {
	private BoardListServiceI blservice;
	// 게시판 상세보기
//		@Test
//		public void detailBoardtest() {
//			/*** Given ***/
//			blservice = new BoardListService();
//
//			BoardListVo vo = new BoardListVo();
//			vo.setBoard_no(1);
//			vo.setPost_no(1);
//			vo.setUser_id("con");
//			/*** When ***/
//			vo = blservice.selectPost(vo);
//			/*** Then ***/
//			assertEquals("1번글", vo.getTitle());
//
//		}
//
//		// 게시글 쓰기
//		@Test
//		public void insertPost() {
//			/*** Given ***/
//			blservice = new BoardListService();
////			(#{board_no},SEQ_PNO.NEXTVAL,#{user_id},#{title},SYSDATE,#{CONTENT},1,null,SEQ_PNO.NEXTVAL,null)
//			BoardListVo vo = new BoardListVo();
//			vo.setBoard_no(2);
//			vo.setUser_id("con");
//			vo.setTitle("1번글");
//			vo.setContent("안녕하세요");
//			/*** When ***/
//			int cnt = blservice.insertPost(vo);
//			/*** Then ***/
//			assertEquals(1, cnt);
//		}
		@Test
		public void insertFile() {
			/*** Given ***/
			FileVo fVo = new FileVo();
			fVo.setBoard_no(2);
			fVo.setUser_id("con");
			fVo.setPost_no(27);
			fVo.setFilenm("profile");
			fVo.setRealfilenm("c:uplode/profile.png");
			FileServiceI service = new FileService();
			/*** When ***/
			int File = service.insertFile(fVo);
			/*** Then ***/
			assertEquals(1, File);
		}
		
		
}
