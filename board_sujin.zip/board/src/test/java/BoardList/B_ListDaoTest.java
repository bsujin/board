package BoardList;

import static org.junit.Assert.*;

import org.junit.Test;

import kr.or.ddit.board.model.BoardListVo;
import kr.or.ddit.boardList.repository.BoardListDao;
import kr.or.ddit.file.model.FileVo;
import kr.or.ddit.file.repository.FileDao;
import kr.or.ddit.file.repository.FileDaoI;
import kr.or.ddit.file.service.FileServiceI;

public class B_ListDaoTest {
	private BoardListDao bldao;

	// 게시판 상세보기

//	@Test
//	public void detailBoardtest() {
//		/*** Given ***/
//		bldao = new BoardListDao();
//
//		BoardListVo vo = new BoardListVo();
//		vo.setBoard_no(1);
//		vo.setPost_no(1);
//		vo.setUser_id("con");
//		/*** When ***/
//		vo = bldao.selectPost(vo);
//		/*** Then ***/
//		assertEquals("1번글", vo.getTitle());
//
//	}

//	// 게시글 쓰기
//	@Test
//	public void insertPost() {
//		/*** Given ***/
//		bldao = new BoardListDao();
////		(#{board_no},SEQ_PNO.NEXTVAL,#{user_id},#{title},SYSDATE,#{CONTENT},1,null,SEQ_PNO.NEXTVAL,null)
//		BoardListVo vo = new BoardListVo();
//		vo.setBoard_no(2);
//		vo.setUser_id("con");
//		vo.setTitle("1번글");
//		vo.setContent("안녕하세요");
//		/*** When ***/
//		int cnt = bldao.insertPost(vo);
//		/*** Then ***/
//		assertEquals(1, cnt);
//	}
	
//	@Test
//	public void insertFile() {
//		/*** Given ***/
//		FileVo fVo = new FileVo();
//		fVo.setBoard_no(2);
//		fVo.setUser_id("con");
//		fVo.setPost_no(27);
//		fVo.setFilenm("profile");
//		fVo.setRealfilenm("c:uplode/profile.png");
//		FileDaoI dao = new FileDao();
//		/*** When ***/
//		int File = dao.insertFile(fVo);
//		/*** Then ***/
//		assertEquals(1, File);
//	}
	
	@Test
	public void updateFile() {
		/*** Given ***/
		FileVo fVo = new FileVo();
		fVo.setFilenm("profile");
		fVo.setRealfilenm("c:uplode/profile.png");
		fVo.setFileno(4);
		FileDaoI dao = new FileDao();
		/*** When ***/
		int File = dao.modifyFile(fVo);
		/*** Then ***/
		assertEquals(1, File);
	}
	
	
	

}
