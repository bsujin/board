package kr.or.ddit.boardList.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import kr.or.ddit.board.model.BoardListVo;
import kr.or.ddit.boardList.repository.BoardListDao;
import kr.or.ddit.boardList.repository.BoardListDaoI;
import kr.or.ddit.file.model.FileVo;
import kr.or.ddit.page.model.PageVo;

public class BoardListService implements BoardListServiceI{
	private BoardListDaoI dao = new BoardListDao();

	@Override
	public List<BoardListVo> selectBoardList(int board_no) {
		return dao.selectBoardList(board_no);
	}

//	@Override
//	public List<BoardListVo> pagingBoardList(PageVo vo) {
//		// TODO Auto-generated method stub
//		return dao.pagingBoardList(vo);
//	}
	
	@Override
	public Map<String,Object> pagingBoardList(PageVo vo) {
		
		Map<String,Object> map = new HashMap<>();
		
		List<BoardListVo> boardList = dao.pagingBoardList(vo);
		int boardCnt = dao.allBoardCnt(vo);
		
		map.put("boardList", boardList);
		map.put("boardCnt", boardCnt);
		
		return map;
	}

	@Override
	public int allBoardCnt(PageVo vo) {
		// TODO Auto-generated method stub
		return dao.allBoardCnt(vo);
	}

	@Override
	public int insertPost(BoardListVo vo) {
		// TODO Auto-generated method stub
		return dao.insertPost(vo);
	}

	@Override
	public int deletePost(BoardListVo vo) {
		// TODO Auto-generated method stub
		return dao.deletePost(vo);
	}

	@Override
	public int modifyPost(BoardListVo vo) {
		// TODO Auto-generated method stub
		return dao.modifyPost(vo);
	}


	@Override
	public BoardListVo selectPost(BoardListVo vo) {
		return dao.selectPost(vo);
	}

	@Override
	public int selectMaxPost_no() {
		return dao.selectMaxPost_no();
	}

	
	
//	@Override
//	public Map<String,Object> searchPagingBoard(PageVo vo) {
//		
//		Map<String,Object> map = new HashMap<>();
//		
//		List<BoardVo> boardList = dao.searchPagingBoard(vo);
//		int boardCnt = dao.allBoardCnt(vo);
//		
//		map.put("boardList", boardList);
//		map.put("boardCnt", boardCnt);
//		
//		return map;
//	}


}
