package kr.or.ddit.file.service;

import java.util.List;

import kr.or.ddit.file.model.FileVo;

public interface FileServiceI {

// 파일 부분
		int insertFile(FileVo vo);
		
		int modifyFile(FileVo vo);

		List<FileVo> selectFileList(FileVo vo);

		FileVo selectFile(FileVo vo);

		int deleteFile(FileVo vo);

}
