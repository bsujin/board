package kr.or.ddit.board.repository;

import java.util.List;

import kr.or.ddit.board.model.BoardListVo;
import kr.or.ddit.board.model.BoardVo;
import kr.or.ddit.page.model.PageVo;
import kr.or.ddit.user.model.UserVo;

public interface BoardDaoI {
	// 사용자의 게시판 리스트 가져오기
	List<BoardVo> selectBoard(String userid);
	
	// 게시판 등록
	int addBoard(BoardVo boardVo);
	
	// 활성상태 수정
	int modifyBoard(BoardVo boardVo);
	
	
	
}