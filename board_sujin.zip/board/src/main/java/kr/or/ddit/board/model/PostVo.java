package kr.or.ddit.board.model;

import java.util.Date;

public class PostVo {

	//boardList
	int board_no;
	int post_no;
	String user_id;
	String title;
	Date reg_date;
	String content;
	int delete_act;
	String re_content;
	int post_rno;
	String ruser_id;
	
	//파일
	int fileno;
	String filenm;
	String realfilenm;
	
	// 댓글
	int comm_no;
	String comm;
	Date comm_date;
	int next_comm;
	String next_user_id;
	int delete_cact;

	public PostVo() {}

	public PostVo(int board_no, int post_no, String user_id, String title, Date reg_date, String content,
			int delete_act, String re_content, int post_rno, String ruser_id, int fileno, String filenm,
			String realfilenm, int comm_no, String comm, Date comm_date, int next_comm, String next_user_id,
			int delete_cact) {
		super();
		this.board_no = board_no;
		this.post_no = post_no;
		this.user_id = user_id;
		this.title = title;
		this.reg_date = reg_date;
		this.content = content;
		this.delete_act = delete_act;
		this.re_content = re_content;
		this.post_rno = post_rno;
		this.ruser_id = ruser_id;
		this.fileno = fileno;
		this.filenm = filenm;
		this.realfilenm = realfilenm;
		this.comm_no = comm_no;
		this.comm = comm;
		this.comm_date = comm_date;
		this.next_comm = next_comm;
		this.next_user_id = next_user_id;
		this.delete_cact = delete_cact;
	}

	@Override
	public String toString() {
		return "PostVo [board_no=" + board_no + ", post_no=" + post_no + ", user_id=" + user_id + ", title=" + title
				+ ", reg_date=" + reg_date + ", content=" + content + ", delete_act=" + delete_act + ", re_content="
				+ re_content + ", post_rno=" + post_rno + ", ruser_id=" + ruser_id + ", fileno=" + fileno + ", filenm="
				+ filenm + ", realfilenm=" + realfilenm + ", comm_no=" + comm_no + ", comm=" + comm + ", comm_date="
				+ comm_date + ", next_comm=" + next_comm + ", next_user_id=" + next_user_id + ", delete_cact="
				+ delete_cact + "]";
	}

	public int getBoard_no() {
		return board_no;
	}

	public void setBoard_no(int board_no) {
		this.board_no = board_no;
	}

	public int getPost_no() {
		return post_no;
	}

	public void setPost_no(int post_no) {
		this.post_no = post_no;
	}

	public String getUser_id() {
		return user_id;
	}

	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Date getReg_date() {
		return reg_date;
	}

	public void setReg_date(Date reg_date) {
		this.reg_date = reg_date;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public int getDelete_act() {
		return delete_act;
	}

	public void setDelete_act(int delete_act) {
		this.delete_act = delete_act;
	}

	public String getRe_content() {
		return re_content;
	}

	public void setRe_content(String re_content) {
		this.re_content = re_content;
	}

	public int getPost_rno() {
		return post_rno;
	}

	public void setPost_rno(int post_rno) {
		this.post_rno = post_rno;
	}

	public String getRuser_id() {
		return ruser_id;
	}

	public void setRuser_id(String ruser_id) {
		this.ruser_id = ruser_id;
	}

	public int getFileno() {
		return fileno;
	}

	public void setFileno(int fileno) {
		this.fileno = fileno;
	}

	public String getFilenm() {
		return filenm;
	}

	public void setFilenm(String filenm) {
		this.filenm = filenm;
	}

	public String getRealfilenm() {
		return realfilenm;
	}

	public void setRealfilenm(String realfilenm) {
		this.realfilenm = realfilenm;
	}

	public int getComm_no() {
		return comm_no;
	}

	public void setComm_no(int comm_no) {
		this.comm_no = comm_no;
	}

	public String getComm() {
		return comm;
	}

	public void setComm(String comm) {
		this.comm = comm;
	}

	public Date getComm_date() {
		return comm_date;
	}

	public void setComm_date(Date comm_date) {
		this.comm_date = comm_date;
	}

	public int getNext_comm() {
		return next_comm;
	}

	public void setNext_comm(int next_comm) {
		this.next_comm = next_comm;
	}

	public String getNext_user_id() {
		return next_user_id;
	}

	public void setNext_user_id(String next_user_id) {
		this.next_user_id = next_user_id;
	}

	public int getDelete_cact() {
		return delete_cact;
	}

	public void setDelete_cact(int delete_cact) {
		this.delete_cact = delete_cact;
	}

}
