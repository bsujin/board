package kr.or.ddit.user.dao;

import org.apache.ibatis.session.SqlSession;

import kr.or.ddit.db.MybatisUtill;
import kr.or.ddit.user.model.UserVo;

public class UserDao implements UserDaoI {

	@Override
	public UserVo selectMember(String userid) {
		SqlSession sqlSession = MybatisUtill.getSqlSession();
		
		UserVo user = sqlSession.selectOne("user.selectMember",userid);
		
		sqlSession.close();
		
		return user;
	}

	
}
