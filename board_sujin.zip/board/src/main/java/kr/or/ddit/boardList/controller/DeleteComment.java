package kr.or.ddit.boardList.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.or.ddit.comment.service.CommentService;
import kr.or.ddit.comment.service.CommentServiceI;

@WebServlet("/deleteComment")
public class DeleteComment extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		int comm_no = Integer.parseInt(req.getParameter("comm_no"));
		int boardno = Integer.parseInt(req.getParameter("cboard_no"));
		int postno = Integer.parseInt(req.getParameter("cpost_no"));
		String userid = req.getParameter("cuserid");
		
		CommentServiceI service = new CommentService();
		service.deleteComment(comm_no);
		
		resp.sendRedirect(req.getContextPath()+"/postDetail?boardno="+boardno+"&postno="+postno+"&userid="+userid);
		
	}

}
