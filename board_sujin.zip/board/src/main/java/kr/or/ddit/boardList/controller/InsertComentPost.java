package kr.or.ddit.boardList.controller;

import java.io.IOException;
import java.util.Collection;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import kr.or.ddit.board.file.FileUtil;
import kr.or.ddit.board.model.BoardListVo;
import kr.or.ddit.boardList.service.BoardListService;
import kr.or.ddit.boardList.service.BoardListServiceI;
import kr.or.ddit.file.model.FileVo;
import kr.or.ddit.file.service.FileService;
import kr.or.ddit.file.service.FileServiceI;

@MultipartConfig
@WebServlet("/comentPost")
public class InsertComentPost extends HttpServlet {

	private static final Logger logger = LoggerFactory.getLogger(InsertComentPost.class);

	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		int boardno = Integer.parseInt(req.getParameter("boardno"));
		String userid = req.getParameter("userid");
		int post_rno = Integer.parseInt(req.getParameter("postno"));
		req.setAttribute("boardno", boardno);
		req.setAttribute("post_rno", post_rno);
		req.getRequestDispatcher("/boardList/insertCommentPost.jsp").forward(req, resp);
	}

	protected synchronized void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		int boardno = Integer.parseInt(req.getParameter("boardno"));
		String userid = req.getParameter("userid");
		String title = req.getParameter("title");
		String cont = req.getParameter("content");
		int post_rno = Integer.parseInt(req.getParameter("postno"));
		
		logger.debug("boardno:{}", boardno);
		logger.debug("userid:{}", userid);
		logger.debug("title:{}", title);
		logger.debug("cont:{}", cont);
		
		BoardListVo boardVo = new BoardListVo();
		boardVo.setBoard_no(boardno);
		boardVo.setUser_id(userid);
		boardVo.setTitle(title);
		boardVo.setPost_bno(boardno);
		boardVo.setPost_rno(post_rno);
		
		String filenm = "";
		String realFilenm = "";
		BoardListServiceI service = new BoardListService();
		
		int insertCnt = 0;
		try {
			boardVo.setContent(cont);
			insertCnt = service.insertPost(boardVo);
		} catch (Exception e) {
			e.printStackTrace();
			insertCnt = 0;
		}
		
		if(insertCnt == 1) {
		int postno = service.selectMaxPost_no();
		logger.debug("postno : {}", postno);
			FileVo fileVo = new FileVo();
			fileVo.setBoard_no(boardno);
			fileVo.setPost_no(postno);
			fileVo.setUser_id(userid);
			
			Collection<Part> parts = req.getParts();
			for(Part p : parts) {
				if(p.getSize()>0) {
					if(p.getHeader("Content-Disposition").contains("name=\"fileName\";")) {
						filenm = FileUtil.getFileName(p.getHeader("Content-Disposition"));
						String fileExtension = FileUtil.getFileExtension(filenm);
						realFilenm = UUID.randomUUID().toString()+fileExtension;
						fileVo.setFilenm(filenm);
						fileVo.setRealfilenm(realFilenm);
						p.write("c:/uploadFile/"+realFilenm);
						FileServiceI fservice = new FileService();
						fservice.insertFile(fileVo);
					}
				}
			}
			resp.sendRedirect(req.getContextPath()+"/boardList?board_no="+boardno);
		}else {
			doGet(req, resp);
		}
		
		
	}

}
