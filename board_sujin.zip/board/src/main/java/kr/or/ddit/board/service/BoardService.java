package kr.or.ddit.board.service;

import java.util.List;

import kr.or.ddit.board.model.BoardVo;
import kr.or.ddit.board.repository.BoardDao;
import kr.or.ddit.board.repository.BoardDaoI;

public class BoardService implements BoardServiceI {

	private BoardDaoI dao = new BoardDao();


	// 게시판 목록 가져오기 
	@Override
	public List<BoardVo> selectBoard(String userid) {
		return dao.selectBoard(userid);
	}

	@Override
	public int addBoard(BoardVo boardVo) {
		return dao.addBoard(boardVo);
	}

	@Override
	public int modifyBoard(BoardVo boardVo) {
		return dao.modifyBoard(boardVo);

	}



}
