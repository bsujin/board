package kr.or.ddit.boardList.controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import kr.or.ddit.board.file.FileUtil;
import kr.or.ddit.board.model.BoardListVo;
import kr.or.ddit.boardList.service.BoardListService;
import kr.or.ddit.boardList.service.BoardListServiceI;
import kr.or.ddit.file.model.FileVo;
import kr.or.ddit.file.service.FileService;
import kr.or.ddit.file.service.FileServiceI;

@MultipartConfig
@WebServlet("/modifyPost")
public class ModifyPost extends HttpServlet {
	
	private static final Logger logger = LoggerFactory.getLogger(ModifyPost.class);
	private BoardListServiceI service;
	private FileServiceI fService;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		int board_no = Integer.parseInt(request.getParameter("boardno"));
		int post_no = Integer.parseInt(request.getParameter("postno"));
		String userid = request.getParameter("userid");

		BoardListVo vo = new BoardListVo();
		vo.setBoard_no(board_no);
		vo.setPost_no(post_no);
		vo.setUser_id(userid);
		
		service = new BoardListService();
		BoardListVo post = service.selectPost(vo);

		logger.debug("BoardListVo : {}", post);

		fService = new FileService();
		FileVo fileVo = new FileVo();
		fileVo.setBoard_no(board_no);
		fileVo.setPost_no(post_no);
		fileVo.setUser_id(userid);

		FileVo file = fService.selectFile(fileVo);
		if(file!=null) {
		int fileno = file.getFileno();
		request.setAttribute("fileno", fileno);
		logger.debug("fileno:{}", fileno);
		}
		request.setAttribute("fileList", file);
		request.setAttribute("post", post);
		request.setAttribute("board_no", board_no);

		request.getRequestDispatcher("/boardList/modifyPost.jsp").forward(request, response);

	}

	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		int boardno = Integer.parseInt(req.getParameter("boardno"));
		int postno = Integer.parseInt(req.getParameter("postno"));
		String userid = req.getParameter("userid");
		String title = req.getParameter("title");
		String cont = req.getParameter("content");
		String fParam = req.getParameter("fileno");
		int	fileno = fParam == null || fParam.equals("") ? 0 : Integer.parseInt(req.getParameter("fileno"));
		
		logger.debug("boardno {}",Integer.parseInt(req.getParameter("boardno")));
		logger.debug("postno {}",Integer.parseInt(req.getParameter("postno")));
		logger.debug("userid{}", req.getParameter("userid"));
		logger.debug("title{}", req.getParameter("title"));
		logger.debug("cont{}",req.getParameter("content"));

		BoardListVo vo = new BoardListVo();
		vo.setBoard_no(boardno);
		vo.setPost_no(postno);
		vo.setUser_id(userid);
		vo.setTitle(title);
		vo.setContent(cont);

		int updateCnt = 0;

		try {
			updateCnt = service.modifyPost(vo);
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (updateCnt == 1) {
			FileVo fileVo = new FileVo();
			Collection<Part> parts = req.getParts();
			for(Part att : parts) {
//			Part att = req.getPart("filenm");
			String filename = "";
			String realFilename = "";
			if (att.getSize() > 0) {
				// 파일 이름과 확장자를 가져오기
				filename = FileUtil.getFileName(att.getHeader("Content-Disposition"));
				String fileExtension = FileUtil.getFileExtension(filename);
				
				// 파일확장자가 없는 경우는 상관 없으나 존재하면 toString 뒤에 확장자를 붙여줘야한다
				 realFilename = UUID.randomUUID().toString() + fileExtension;
				
				att.write("c:\\upload\\" + realFilename);
				fileVo.setFilenm(filename);
				fileVo.setRealfilenm(realFilename);
				
				logger.debug("file:{}", filename);
			}}if(fileno!=0) {
			fileVo.setFileno(fileno);
			fService = new FileService();
			fService.modifyFile(fileVo);
			}else {
				fileVo.setBoard_no(boardno);
				fileVo.setPost_no(postno);
				fileVo.setUser_id(userid);
				fService = new FileService();
				fService.insertFile(fileVo);
			}
			
			resp.sendRedirect(req.getContextPath() + "/boardList?board_no=" + boardno);
		} else {
			doGet(req, resp);
		}
	}

}
