package kr.or.ddit.file.repository;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import kr.or.ddit.db.MybatisUtill;
import kr.or.ddit.file.model.FileVo;

public class FileDao implements FileDaoI {

	@Override
	public int insertFile(FileVo vo) {
		SqlSession sqlSession = MybatisUtill.getSqlSession();

		int insertCnt = sqlSession.insert("file.insertFile", vo);

		if (insertCnt == 1) {
			sqlSession.commit();
		} else {
			sqlSession.rollback();
		}

		sqlSession.close();

		return insertCnt;
	}
	
	@Override
	public int modifyFile(FileVo vo) {
		SqlSession sqlSession = MybatisUtill.getSqlSession();

		int modifyCnt = sqlSession.insert("file.modifyFile", vo);

		if (modifyCnt == 1) {
			sqlSession.commit();
		} else {
			sqlSession.rollback();
		}

		sqlSession.close();

		return modifyCnt;
	}


	@Override
	public List<FileVo> selectFileList(FileVo vo) {
		SqlSession sqlSession = MybatisUtill.getSqlSession();
		
		List<FileVo> fileList = sqlSession.selectList("file.selectFileList",vo);
		
		sqlSession.close();
		
		return fileList;
	}

	@Override
	public FileVo selectFile(FileVo vo) {
		SqlSession sqlSession = MybatisUtill.getSqlSession();
		
		FileVo fileVo = sqlSession.selectOne("file.selectFile", vo);
		
		sqlSession.close();
		
		return fileVo;
	}
	
	@Override
	public int deleteFile(FileVo vo) {
		SqlSession sqlSession = MybatisUtill.getSqlSession();
		
		int deleteCnt = sqlSession.delete("file.deleteFile", vo);
	
		if(deleteCnt==1) {
			sqlSession.commit();			
		}else {
			sqlSession.rollback();
		}
		
		sqlSession.close();
		
		return deleteCnt;
	}



}
