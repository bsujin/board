package kr.or.ddit.comment.repository;

import java.util.List;

import kr.or.ddit.comment.model.CommentsVo;

public interface CommentDaoI {

	int insertComment(CommentsVo vo);
	
	List<CommentsVo> selectComment(CommentsVo vo);
	
	int deleteComment(int comm_no);
	
}