package kr.or.ddit.board.repository;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import kr.or.ddit.board.model.BoardListVo;
import kr.or.ddit.board.model.BoardVo;
import kr.or.ddit.db.MybatisUtill;
import kr.or.ddit.page.model.PageVo;
import kr.or.ddit.user.model.UserVo;

public class BoardDao implements BoardDaoI {

	@Override
	public List<BoardVo> selectBoard(String userid) {
		SqlSession sqlSession = MybatisUtill.getSqlSession();
		List<BoardVo> board = sqlSession.selectList("board.selectBoard", userid);
		sqlSession.close();
		return board;
	}

	@Override
	public int addBoard(BoardVo boardVo) {
		SqlSession sqlSession = MybatisUtill.getSqlSession();
		int addBoard = sqlSession.insert("board.insertBoard", boardVo);
		if (addBoard == 1) {
			sqlSession.commit();
		} else {
			sqlSession.rollback();
		}

		sqlSession.close();

		return addBoard;
	}

	@Override
	public int modifyBoard(BoardVo boardVo) {
		SqlSession sqlSession = MybatisUtill.getSqlSession();
		int modifyBoard = sqlSession.update("board.modifyBoard", boardVo);

		if (modifyBoard == 1) {
			sqlSession.commit();
		} else {
			sqlSession.rollback();
		}
		sqlSession.close();
		return modifyBoard;
	}

	



}
