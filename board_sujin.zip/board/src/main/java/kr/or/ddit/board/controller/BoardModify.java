package kr.or.ddit.board.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import kr.or.ddit.board.model.BoardVo;
import kr.or.ddit.board.service.BoardService;
import kr.or.ddit.board.service.BoardServiceI;
import kr.or.ddit.user.model.UserVo;

@WebServlet("/boardSet")
public class BoardModify extends HttpServlet {

	private static final Logger logger = LoggerFactory.getLogger(BoardModify.class);
	private BoardServiceI service = new BoardService();

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

//	      String userid = req.getParameter("userid");
//	      
//	      UserVo user = service.selectMember(userid);
//	      
//	      req.setAttribute("user", user);
//	      

		doPost(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String userid = req.getParameter("userid");
		int boardno = Integer.parseInt(req.getParameter("boardno"));
		String act = req.getParameter("act");
		logger.debug("userid{}", req.getParameter("userid"));
		logger.debug("boardno{}", req.getParameter("boardno"));
		logger.debug(req.getParameter("activation"));

		int activation = act.equals("") || act.equals("1") ? 1 : Integer.parseInt(req.getParameter("act"));

		BoardVo vo = new BoardVo();
		vo.setBoard_no(boardno);
		vo.setActivation(activation);
		vo.setUser_id(userid);

		int updateCnt = 0;

		try {
			// 예외 처리를 해줘야한다
			updateCnt = service.modifyBoard(vo);
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (updateCnt == 1) {
			resp.sendRedirect(req.getContextPath() + "/boardMain");
		} else {
			req.setAttribute("error", "수정오류");
			req.getRequestDispatcher("/board/boardMain.jsp").forward(req, resp);
		}

	}

}
