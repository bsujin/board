package kr.or.ddit.boardList.repository;

import java.util.List;

import kr.or.ddit.board.model.BoardListVo;
import kr.or.ddit.file.model.FileVo;
import kr.or.ddit.page.model.PageVo;

public interface BoardListDaoI {

	// 사용하는 게시판의 게시글 리스트 가져오기
	List<BoardListVo> selectBoardList(int board_no);

	// 페이징처리
	List<BoardListVo> pagingBoardList(PageVo vo);

	//	게시글 전체 카운트
	int allBoardCnt(PageVo vo);

	//	게시글 등록하기 
	int insertPost(BoardListVo vo);

	// 게시글 삭제
	int deletePost(BoardListVo vo);
	
	// 게시글 수정
	int modifyPost(BoardListVo vo);
	
	// 게시글 상세조회
	BoardListVo selectPost(BoardListVo vo);
	
	// 파일 등록 시 post번호 가져오기 
	int selectMaxPost_no();
	
	
	
	

}