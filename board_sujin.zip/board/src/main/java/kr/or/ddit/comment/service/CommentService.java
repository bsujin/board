package kr.or.ddit.comment.service;

import java.util.List;

import kr.or.ddit.comment.model.CommentsVo;
import kr.or.ddit.comment.repository.CommentDao;
import kr.or.ddit.comment.repository.CommentDaoI;

public class CommentService implements CommentServiceI{
	private CommentDaoI dao = new CommentDao();

	@Override
	public int insertComment(CommentsVo vo) {
		return dao.insertComment(vo);
	}

	@Override
	public List<CommentsVo> selectComment(CommentsVo vo) {
		return dao.selectComment(vo);
	}

	@Override
	public int deleteComment(int comm_no) {
		return dao.deleteComment(comm_no);
	}
	

}
