package kr.or.ddit.board.controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import kr.or.ddit.board.model.BoardListVo;
import kr.or.ddit.board.model.BoardVo;
import kr.or.ddit.boardList.service.BoardListService;
import kr.or.ddit.boardList.service.BoardListServiceI;
import kr.or.ddit.page.model.PageVo;

@WebServlet("/boardList")
public class BoardList extends HttpServlet {

	private static final Logger logger = LoggerFactory.getLogger(BoardList.class);
	private BoardListServiceI bListService;

	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String no = req.getParameter("board_no");
		String pageParam = req.getParameter("page");
		String pageSizeParam = req.getParameter("pageSize");
		
		int page = pageParam == null ? 1 : Integer.parseInt(req.getParameter("page"));
		int	pageSize = pageSizeParam == null ? 10 : Integer.parseInt(req.getParameter("pageSize"));
		
		logger.debug("board_no{}", no);
		logger.debug("page{}", page);
		logger.debug("pageSize{}", pageSize);

		int board_no =0;
		if(no == null) {
			resp.sendRedirect(req.getContextPath() + "/main.jsp");
		}else {
			board_no = Integer.parseInt(req.getParameter("board_no"));
			PageVo pageVo = new PageVo(page, pageSize, board_no);
			bListService = new BoardListService();
			
			Map<String, Object> map = bListService.pagingBoardList(pageVo);
			
			List<BoardListVo> blist = (List<BoardListVo>) bListService.selectBoardList(board_no);
			List<BoardListVo> boardList = (List<BoardListVo>)map.get("boardList");
			int boardCnt = (int)map.get("boardCnt");
			int pagination = (int)Math.ceil((double)boardCnt/pageSize);
		
		req.setAttribute("pagination", pagination);
		req.setAttribute("pageVo", pageVo);
		req.setAttribute("bList", blist);
		req.setAttribute("mapList", blist);
		req.setAttribute("board_no", no);
		
		logger.debug("boardList 값 : {}", boardList);
		logger.debug("pagination 값 : {}", pagination);
		logger.debug("pageVo 값 : {}", pageVo);
		logger.debug("bList 값 : {}", blist);
		logger.debug("board_no 값 : {}", no);
		
		req.getRequestDispatcher("/board/boardList.jsp").forward(req, resp);
		}
	}

}
