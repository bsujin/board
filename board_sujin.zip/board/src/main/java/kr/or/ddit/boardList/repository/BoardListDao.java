package kr.or.ddit.boardList.repository;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import kr.or.ddit.board.model.BoardListVo;
import kr.or.ddit.db.MybatisUtill;
import kr.or.ddit.file.model.FileVo;
import kr.or.ddit.page.model.PageVo;

public class BoardListDao implements BoardListDaoI {

	@Override
	public List<BoardListVo> selectBoardList(int board_no) {
		SqlSession sqlSession = MybatisUtill.getSqlSession();
		List<BoardListVo> board = sqlSession.selectList("blist.selectBoardList", board_no);
		sqlSession.close();
		return board;
	}

	@Override
	public List<BoardListVo> pagingBoardList(PageVo vo) {
		SqlSession sqlSession = MybatisUtill.getSqlSession();

		List<BoardListVo> boardList = sqlSession.selectList("blist.pagingBoardList", vo);

		sqlSession.close();

		return boardList;
	}

	@Override
	public int allBoardCnt(PageVo vo) {
		SqlSession sqlSession = MybatisUtill.getSqlSession();

		int boardCnt = sqlSession.selectOne("blist.allBListCnt", vo);

		sqlSession.close();

		return boardCnt;
	}

	@Override
	public int insertPost(BoardListVo vo) {
		SqlSession sqlSession = MybatisUtill.getSqlSession();

		int insertCnt = sqlSession.insert("blist.insertPost", vo);

		if (insertCnt == 1) {
			sqlSession.commit();
		} else {
			sqlSession.rollback();
		}

		sqlSession.close();

		return insertCnt;
	}

	@Override
	public int deletePost(BoardListVo vo) {
		SqlSession sqlSession = MybatisUtill.getSqlSession();

		int deleteCnt = sqlSession.delete("blist.deletePost", vo);

		if (deleteCnt == 1) {
			sqlSession.commit();
		} else {
			sqlSession.rollback();
		}

		sqlSession.close();

		return deleteCnt;
	}

	@Override
	public int modifyPost(BoardListVo vo) {
		SqlSession sqlSession = MybatisUtill.getSqlSession();
		
		int updateCnt = sqlSession.update("blist.modifyPost", vo);
	
		if(updateCnt==1) {
			sqlSession.commit();			
		}else {
			sqlSession.rollback();
		}
		
		sqlSession.close();
		
		return updateCnt;
	}
	
	@Override
	public BoardListVo selectPost(BoardListVo vo) {
		SqlSession sqlSession = MybatisUtill.getSqlSession();

		BoardListVo  post = sqlSession.selectOne("blist.selectPost", vo);

		sqlSession.close();

		return post;
	}


	@Override
	public int selectMaxPost_no() {
		SqlSession sqlSession = MybatisUtill.getSqlSession();

		int post_no = sqlSession.selectOne("blist.selectMaxPost_no");

		sqlSession.close();

		return post_no;
	}


}
