package kr.or.ddit.user.dao;

import kr.or.ddit.user.model.UserVo;

public interface UserDaoI {

	// userid에 해당하는 사용자 한명의 정보 조회
	UserVo selectMember(String userid);

}
