package kr.or.ddit.boardList.controller;


import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import kr.or.ddit.board.service.BoardService;
import kr.or.ddit.boardList.service.BoardListService;
import kr.or.ddit.boardList.service.BoardListServiceI;
import kr.or.ddit.comment.model.CommentsVo;
import kr.or.ddit.comment.service.CommentService;
import kr.or.ddit.comment.service.CommentServiceI;

@WebServlet("/commentList")
public class CommentList extends HttpServlet {

	private static final Logger logger = LoggerFactory.getLogger(CommentList.class);
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}

	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		int boardno = Integer.parseInt(req.getParameter("boardno"));
		int postno = Integer.parseInt(req.getParameter("postno"));
		String userid = req.getParameter("userid");
		logger.debug("boardno : {}", boardno);
		logger.debug("postno : {}", postno);
		logger.debug("userid : {}", userid);
		
		
		CommentsVo cVo = new CommentsVo();
		cVo.setBoard_no(boardno);
		cVo.setPost_no(postno);
		cVo.setUser_id(userid);
		
		
		logger.debug(cVo.toString());
		
		CommentServiceI service = new CommentService();
		
		List<CommentsVo> cList = service.selectComment(cVo);
		req.setAttribute("commentList", cList);
		}

}
