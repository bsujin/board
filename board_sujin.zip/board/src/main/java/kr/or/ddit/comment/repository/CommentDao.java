package kr.or.ddit.comment.repository;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import kr.or.ddit.comment.model.CommentsVo;
import kr.or.ddit.db.MybatisUtill;

public class CommentDao implements CommentDaoI {
	@Override
	public int insertComment(CommentsVo vo) {
		SqlSession sqlSession = MybatisUtill.getSqlSession();
		
		int insertCnt = sqlSession.insert("comment.insertComment", vo);
		
		if(insertCnt==1) {
			sqlSession.commit();			
		}else {
			sqlSession.rollback();
		}
		
		sqlSession.close();
		
		return insertCnt;
	}

	@Override
	public List<CommentsVo> selectComment(CommentsVo vo) {
		SqlSession sqlSession = MybatisUtill.getSqlSession();
		
		List<CommentsVo> commentList = sqlSession.selectList("comment.selectComment", vo);
		
		sqlSession.close();
		
		return commentList;
	}

	@Override
	public int deleteComment(int comm_no) {
		SqlSession sqlSession = MybatisUtill.getSqlSession();
		
		int deleteCnt = sqlSession.delete("comment.deleteComment", comm_no);
	
		if(deleteCnt==1) {
			sqlSession.commit();			
		}else {
			sqlSession.rollback();
		}
		
		sqlSession.close();
		
		return deleteCnt;
	}

}
