package kr.or.ddit.file.service;

import java.util.List;

import kr.or.ddit.file.model.FileVo;
import kr.or.ddit.file.repository.FileDao;
import kr.or.ddit.file.repository.FileDaoI;

public class FileService implements FileServiceI{
	private FileDaoI dao = new FileDao();

	@Override
	public int insertFile(FileVo vo) {
		return dao.insertFile(vo);
	}

	@Override
	public List<FileVo> selectFileList(FileVo vo) {
		return dao.selectFileList(vo);
	}

	@Override
	public FileVo selectFile(FileVo vo) {
		return dao.selectFile(vo);
	}

	@Override
	public int deleteFile(FileVo vo) {
		return dao.deleteFile(vo);
	}

	@Override
	public int modifyFile(FileVo vo) {
		return dao.modifyFile(vo);
	}

	


}
