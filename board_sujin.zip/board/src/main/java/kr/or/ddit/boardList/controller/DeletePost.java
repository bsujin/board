package kr.or.ddit.boardList.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import kr.or.ddit.board.model.BoardListVo;
import kr.or.ddit.board.service.BoardService;
import kr.or.ddit.board.service.BoardServiceI;
import kr.or.ddit.boardList.service.BoardListService;
import kr.or.ddit.boardList.service.BoardListServiceI;
import kr.or.ddit.file.model.FileVo;
import kr.or.ddit.file.service.FileServiceI;

@WebServlet("/deletePost")
public class DeletePost extends HttpServlet {
	
	private static final Logger logger = LoggerFactory.getLogger(DeletePost.class);
	private BoardListServiceI service;
	private FileServiceI fservice;
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		int boardno = Integer.parseInt(req.getParameter("boardno"));
		int postno = Integer.parseInt(req.getParameter("postno"));
		String userid = req.getParameter("userid");
		String fParam = req.getParameter("fileno");
		int	fileno = fParam == null || fParam.equals("") ? 0 : Integer.parseInt(req.getParameter("fileno"));
		
		if(fileno!=0) {
		FileVo fileVo = new FileVo();
		fileVo.setFileno(fileno);
		fileVo.setBoard_no(boardno);
		fileVo.setPost_no(postno);
		fileVo.setUser_id(userid);
		fservice.deleteFile(fileVo);
		}
		service = new BoardListService();
		BoardListVo bListVo = new BoardListVo();
		bListVo.setBoard_no(boardno);
		bListVo.setPost_no(postno);
		bListVo.setUser_id(userid);
		service.deletePost(bListVo);
		
		resp.sendRedirect(req.getContextPath()+"/boardList?board_no="+boardno);
		
	}

}
