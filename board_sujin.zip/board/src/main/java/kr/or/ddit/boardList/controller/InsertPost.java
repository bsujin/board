package kr.or.ddit.boardList.controller;

import java.io.IOException;
import java.util.Collection;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import kr.or.ddit.board.file.FileUtil;
import kr.or.ddit.board.model.BoardListVo;
import kr.or.ddit.boardList.service.BoardListService;
import kr.or.ddit.boardList.service.BoardListServiceI;
import kr.or.ddit.file.model.FileVo;
import kr.or.ddit.file.service.FileService;
import kr.or.ddit.file.service.FileServiceI;

@MultipartConfig
@WebServlet("/insertPost")
public class InsertPost extends HttpServlet {

	private static final Logger logger = LoggerFactory.getLogger(InsertPost.class);

	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		int boardno = Integer.parseInt(req.getParameter("boardno"));
		String userid = req.getParameter("userid");
		req.setAttribute("boardno", boardno);
		req.setAttribute("userid", userid);
		logger.debug("userid : {}", userid);
		req.getRequestDispatcher("/boardList/insertPost.jsp").forward(req, resp);
	}

	protected synchronized void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		int boardno = Integer.parseInt(req.getParameter("boardno"));
		String userid = req.getParameter("userid");
		String title = req.getParameter("title");
		String cont = req.getParameter("content");
		
		logger.debug("boardno:{}", boardno);
		logger.debug("userid:{}", userid);
		logger.debug("title:{}", title);
		logger.debug("cont:{}", cont);
		
		BoardListVo boardVo = new BoardListVo();
		boardVo.setBoard_no(boardno);
		boardVo.setUser_id(userid);
		boardVo.setTitle(title);
		
		BoardListServiceI service = new BoardListService();
		
		int insertCnt = 0;
		
		try {
			boardVo.setContent(cont);
			insertCnt = service.insertPost(boardVo);
		} catch (Exception e) {
			e.printStackTrace();
			insertCnt = 0;
		}
		
		if(insertCnt == 1) {
			
		int postno = service.selectMaxPost_no();
		logger.debug("postno : {}", postno);
			FileVo fileVo = new FileVo();
			fileVo.setBoard_no(boardno);
			fileVo.setPost_no(postno);
			fileVo.setUser_id(userid);
			
			int fileCnt = 0;
			Collection<Part> parts = req.getParts();
			for(Part att : parts) {
//			Part att = req.getPart("filenm");
			String filename = "";
			String realFilename = "";
			if (att.getSize() > 0) {
				// 파일 이름과 확장자를 가져오기
				filename = FileUtil.getFileName(att.getHeader("Content-Disposition"));
				String fileExtension = FileUtil.getFileExtension(filename);
				if(filename!=null && fileExtension !=null) {
				// 파일확장자가 없는 경우는 상관 없으나 존재하면 toString 뒤에 확장자를 붙여줘야한다
				realFilename = UUID.randomUUID().toString() + fileExtension;
				att.write("c:\\upload\\" + realFilename);
				fileVo.setFilenm(filename);
				fileVo.setRealfilenm(realFilename);
				FileServiceI fservice = new FileService();
				fileCnt = fservice.insertFile(fileVo);
				logger.debug("file:{}", filename);
				}
			}
			}
			
			resp.sendRedirect(req.getContextPath()+"/boardList?board_no="+boardno);
		}else {
			doGet(req, resp);
		}
		
		
	}

}
