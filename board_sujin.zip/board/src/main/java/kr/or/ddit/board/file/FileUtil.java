package kr.or.ddit.board.file;

public class FileUtil {

	//contentDisposition ==> form-data; name="file"; filename="brown.png"
	public static String getFileName(String contentDisposition) {
		String[] attrs = contentDisposition.split("; ");
		String fileName = "";
		for(String name : attrs) {
			if(name.trim().startsWith("filename")) {
				String[] file = name.split("=");
				fileName=file[1].replaceAll("\"", "");
				
			}
		}
		
		return fileName;
	}
	
	public static String getFileExtension(String filename) {
		//brown.png
		//==>   arr[0]="brown", arr[1]="png";
		//return filename.split("\\.")[1];
		
		//line.brown.png
		
		//brown
		if(filename.indexOf(".") == -1)
			return "";
		
		return "." + filename.substring(filename.lastIndexOf(".") + 1);
	}
}





