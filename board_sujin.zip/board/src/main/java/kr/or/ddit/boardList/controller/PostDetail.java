package kr.or.ddit.boardList.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import kr.or.ddit.board.model.BoardListVo;
import kr.or.ddit.boardList.service.BoardListService;
import kr.or.ddit.boardList.service.BoardListServiceI;
import kr.or.ddit.comment.model.CommentsVo;
import kr.or.ddit.comment.service.CommentService;
import kr.or.ddit.comment.service.CommentServiceI;
import kr.or.ddit.file.model.FileVo;
import kr.or.ddit.file.service.FileService;
import kr.or.ddit.file.service.FileServiceI;

@WebServlet("/postDetail")
public class PostDetail extends HttpServlet {

	private static final Logger logger = LoggerFactory.getLogger(PostDetail.class);
	private BoardListServiceI service;
	private FileServiceI fService;
	private CommentServiceI cservice; 
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		int board_no = Integer.parseInt(req.getParameter("boardno"));
		int post_no = Integer.parseInt(req.getParameter("postno"));
		String userid = req.getParameter("userid");

		logger.debug("board_no{}", board_no);
		logger.debug("post_no{}", post_no);
		logger.debug("userid{}", userid);

		BoardListVo blistVo = new BoardListVo();
		blistVo.setBoard_no(board_no);
		blistVo.setPost_no(post_no);
		blistVo.setUser_id(userid);

		service = new BoardListService();
		BoardListVo post = service.selectPost(blistVo);
		logger.debug("BoardListVo : {}", blistVo.toString());
		
		//파일
		fService = new FileService();
		FileVo fileVo = new FileVo();
		fileVo.setBoard_no(board_no);
		fileVo.setPost_no(post_no);
		fileVo.setUser_id(userid);

		List<FileVo> fileList = fService.selectFileList(fileVo);
		logger.debug("fileList : {}",fileList);

		//댓글
		cservice = new CommentService();
		CommentsVo cVo = new CommentsVo();
		cVo.setBoard_no(board_no);
		cVo.setPost_no(post_no);
		cVo.setUser_id(userid);

		logger.debug("CommentsVo : {}",cVo.toString());
		List<CommentsVo> cList = cservice.selectComment(cVo);
		req.setAttribute("commentList", cList);
		req.setAttribute("post", post);
		req.setAttribute("board_no", board_no);
		req.setAttribute("fileList", fileList);

		req.getRequestDispatcher("/boardList/DetailPost.jsp").forward(req, resp);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
