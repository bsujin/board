package kr.or.ddit.board.repository;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import kr.or.ddit.board.model.BoardInfoVo;
import kr.or.ddit.board.model.BoardVo;
import kr.or.ddit.board.model.CommentVo;
import kr.or.ddit.board.model.FileVo;
import kr.or.ddit.common.model.PageVo;
import kr.or.ddit.db.MybatisUtil;

public class BoardDao implements BoardDaoI{

	@Override
	public List<BoardInfoVo> selectAllBoardInfo() {
		SqlSession sqlSession = MybatisUtil.getSqlSession();
		
		List<BoardInfoVo> boardInfo = sqlSession.selectList("boardinfo.selectAllBoardInfo");
		
		sqlSession.close();
		
		return boardInfo;
	}

	@Override
	public int insertBoardInfo(BoardInfoVo vo) {
		SqlSession sqlSession = MybatisUtil.getSqlSession();
		
		int insertCnt = sqlSession.insert("boardinfo.insertBoardInfo", vo);
		
		if(insertCnt==1) {
			sqlSession.commit();			
		}else {
			sqlSession.rollback();
		}
		
		sqlSession.close();
		
		return insertCnt;
	}

	@Override
	public int modifyBoardInfo(BoardInfoVo vo) {
		SqlSession sqlSession = MybatisUtil.getSqlSession();
		
		int updateCnt = sqlSession.update("boardinfo.modifyBoardInfo", vo);
		
		if(updateCnt==1) {
			sqlSession.commit();			
		}else {
			sqlSession.rollback();
		}
		
		sqlSession.close();
		
		return updateCnt;
	}

	@Override
	public List<BoardVo> searchPagingBoard(PageVo vo) {
		SqlSession sqlSession = MybatisUtil.getSqlSession();
		
		List<BoardVo> boardList = sqlSession.selectList("board.searchPagingBoard",vo);
		
		sqlSession.close();
		
		return boardList;
	}

	@Override
	public int allBoardCnt(PageVo vo) {
		SqlSession sqlSession = MybatisUtil.getSqlSession();
		
		int boardCnt = sqlSession.selectOne("board.allBoardCnt",vo);
		
		sqlSession.close();
		
		return boardCnt;
	}

	@Override
	public int registBoard(BoardVo vo) {
		SqlSession sqlSession = MybatisUtil.getSqlSession();
		
		int insertCnt = sqlSession.insert("board.registBoard", vo);
		
		if(insertCnt==1) {
			sqlSession.commit();			
		}else {
			sqlSession.rollback();
		}
		
		sqlSession.close();
		
		return insertCnt;
	}

	@Override
	public BoardVo selectBoardPost(BoardVo vo) {
		SqlSession sqlSession = MybatisUtil.getSqlSession();
		
		BoardVo boardVo = sqlSession.selectOne("board.selectBoardPost", vo);
		
		sqlSession.close();
		
		return boardVo;
	}

	@Override
	public int registComentBoard(BoardVo vo) {
		SqlSession sqlSession = MybatisUtil.getSqlSession();
		
		int insertCnt = sqlSession.insert("board.registComentBoard", vo);
		
		if(insertCnt==1) {
			sqlSession.commit();			
		}else {
			sqlSession.rollback();
		}
		
		sqlSession.close();
		
		return insertCnt;
	}

	@Override
	public int insertFile(FileVo vo) {
		SqlSession sqlSession = MybatisUtil.getSqlSession();
		
		int insertCnt = sqlSession.insert("file.insertFile", vo);
		
		if(insertCnt==1) {
			sqlSession.commit();			
		}else {
			sqlSession.rollback();
		}
		
		sqlSession.close();
		
		return insertCnt;
	}

	@Override
	public int selectMaxPostNo() {
		SqlSession sqlSession = MybatisUtil.getSqlSession();
		
		int maxPostNo = sqlSession.selectOne("board.selectMaxPostNo");
		
		sqlSession.close();
		
		return maxPostNo;
	}

	@Override
	public List<FileVo> selectFileList(FileVo vo) {
		SqlSession sqlSession = MybatisUtil.getSqlSession();
		
		List<FileVo> fileList = sqlSession.selectList("file.selectFileList",vo);
		
		sqlSession.close();
		
		return fileList;
	}

	@Override
	public FileVo selectFile(FileVo vo) {
		SqlSession sqlSession = MybatisUtil.getSqlSession();
		
		FileVo fileVo = sqlSession.selectOne("file.selectFile", vo);
		
		sqlSession.close();
		
		return fileVo;
	}

	@Override
	public int deleteBoardPost(BoardVo vo) {
		SqlSession sqlSession = MybatisUtil.getSqlSession();
		
		int deleteCnt = sqlSession.delete("board.deleteBoardPost", vo);
	
		if(deleteCnt==1) {
			sqlSession.commit();			
		}else {
			sqlSession.rollback();
		}
		
		sqlSession.close();
		
		return deleteCnt;
	}

	@Override
	public int registComment(CommentVo vo) {
		SqlSession sqlSession = MybatisUtil.getSqlSession();
		
		int insertCnt = sqlSession.insert("comment.registComment", vo);
		
		if(insertCnt==1) {
			sqlSession.commit();			
		}else {
			sqlSession.rollback();
		}
		
		sqlSession.close();
		
		return insertCnt;
	}

	@Override
	public List<CommentVo> selectBoardComment(CommentVo vo) {
		SqlSession sqlSession = MybatisUtil.getSqlSession();
		
		List<CommentVo> commentList = sqlSession.selectList("comment.selectBoardComment", vo);
		
		sqlSession.close();
		
		return commentList;
	}

	@Override
	public int deleteComment(CommentVo vo) {
		SqlSession sqlSession = MybatisUtil.getSqlSession();
		
		int deleteCnt = sqlSession.delete("comment.deleteComment", vo);
	
		if(deleteCnt==1) {
			sqlSession.commit();			
		}else {
			sqlSession.rollback();
		}
		
		sqlSession.close();
		
		return deleteCnt;
	}

	@Override
	public int deleteFile(FileVo vo) {
		SqlSession sqlSession = MybatisUtil.getSqlSession();
		
		int deleteCnt = sqlSession.delete("file.deleteFile", vo);
	
		if(deleteCnt==1) {
			sqlSession.commit();			
		}else {
			sqlSession.rollback();
		}
		
		sqlSession.close();
		
		return deleteCnt;
	}

	@Override
	public int modifyBoard(BoardVo vo) {
		SqlSession sqlSession = MybatisUtil.getSqlSession();
		
		int updateCnt = sqlSession.update("board.modifyBoard", vo);
	
		if(updateCnt==1) {
			sqlSession.commit();			
		}else {
			sqlSession.rollback();
		}
		
		sqlSession.close();
		
		return updateCnt;
	}
	
	
	
	
	
	
	

}
